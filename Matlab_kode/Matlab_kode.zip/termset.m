function [Hn,hn] = termset(A,B,C,K,ymax,ymin,umax,umin)

%Calculating terminal set for MPC
%Some of this could be done more elegantly with the 'polytope' routines in
%the MPT toolbox


nx = size(A,1);
nu = size(B,2);
ny = size(C,1);

big = 1000;

H0 = [eye(nx);-eye(nx)];   %Defining constraints as H*x \leq h
h0 = big*ones(2*nx,1);

Hi = [C;-C;-K;K];
hi = [ymax;-ymin;umax;-umin];
nci = size(hi,1);

ni = 10;
nstep = -1;
while (ni>0)
    ni = 0;
    nstep = nstep + 1;
    if (nstep == 0)
        Dyn = eye(nx);
    else
        Dyn = (A-B*K)*Dyn;
    end 
    for ik = 1:nci
        f = (Hi(ik,:)*Dyn)';
        %[xopt,fval,lambda,exitflag,how]=mpt_solveLP(-f,H0,h0,[],[],[],0);
        [x,fval,exitflag,output,lambda]=linprog(-f,H0,h0);
        if (-fval > hi(ik))
            ni = ni + 1;
            H0 = [H0;f'];
            h0 = [h0;hi(ik)];
        end
    end
end

%Removing redundant constraints from initial 'box'
nc0 = size(H0,1);

H1 = H0(2*nx+1:nc0,:);
h1 = h0(2*nx+1:nc0);

for ik = 1:2*nx
        f = H0(ik,:)';
        [xopt,fval,lambda,exitflag,how]=mpt_solveLP(-f,H0,h0,[],[],[],0);
        if (-fval > h0(ik))
            %nbox = nbox + 1
            H1 = [H1;f'];
            h1 = [h1;h0(ik)];
        end 
end
Hn = H1;  %Could also have checked for redundancy of other constraints 
hn = h1;


            